#define F_CPU 4000000UL
#include <util/delay.h>
#include <avr/interrupt.h>

#define gsm_tx_en (PORTB|=(1<<2))
#define	gsm_tx_dis (PORTB&=~(1<<2))

#define gsm_rx_en (PORTB|=(1<<3))
#define gsm_rx_dis (PORTB&=~(1<<3))

#define zigb_tx_en (PORTB|=(1<<6))
#define	zigb_tx_dis (PORTB&=~(1<<6))

#define zigb_rx_en (PORTB|=(1<<7))
#define zigb_rx_dis (PORTB&=~(1<<7)) 

#define pc_tx_en (PORTB|=(1<<4))
#define pc_tx_dis (PORTB&=~(1<<4))

#define pc_rx_en (PORTB|=(1<<5))
#define pc_rx_dis (PORTB&=~(1<<5)) 





void sendmsg(const char *num ,const char *msg1);
void msgread();
char gps_data[50];
char msgloc;
char number[15],msgdata[20];
void position();

void gsm_initial(void)
{
	cli();
		gsm_rx_en;
		gsm_tx_en;
		zigb_rx_dis;
		zigb_tx_dis;
		pc_rx_dis;
		pc_tx_dis;
	 _delay_ms(100);
	usart_string("AT");
	usart_transmit(0x0D);
	usart_transmit(0x0A);                       
	 _delay_ms(100);
	usart_string("AT+CMGF=1");
	usart_transmit(0x0D);
	usart_transmit(0x0A);                       
	 _delay_ms(100);
	usart_string("AT+CSAS=0");
	usart_transmit(0x0D);
	usart_transmit(0x0A);                       
	 _delay_ms(100);
	usart_string("AT+CMGD=1");                     
	usart_transmit(0x0D);
	usart_transmit(0x0A);                       
	  _delay_ms(1000);
	usart_string("AT+CMGD=2");                     
	usart_transmit(0x0D);
	usart_transmit(0x0A);                       
	 _delay_ms(500);
	sei();
}

void sendmsg1(const char *num ,const char *msg1,const char *msg2,const char *msg3,const char *msg4,const char *msg5)
	{
		cli();
		zigb_tx_dis;
		zigb_rx_dis;
		pc_tx_dis;
		pc_rx_dis;
		gsm_rx_en;
		gsm_tx_en;
		
		lcd_command(0X01);
		_delay_ms(50);
		lcd_string("Sending MSG...");	
		usart_string("AT+CMGS=");
		_delay_ms(100);
		usart_transmit('"');
		_delay_ms(100);
		usart_string(num);
		_delay_ms(100);
		usart_transmit('"');	
		_delay_ms(100);
		usart_transmit(0X0D);
		usart_transmit(0X0A);
		_delay_ms(100);
		
		usart_string("T:");
		_delay_ms(100);
		convert(msg1);
		usart_string(con);
		_delay_ms(100);
		usart_transmit(0X0D);
		usart_transmit(0X0A);
		_delay_ms(100);
		
		usart_string("W:");
		_delay_ms(100);
		convert(msg2);
		_delay_ms(100);
		usart_string(con);
		_delay_ms(100);
		usart_transmit(0X0D);
		usart_transmit(0X0A);
		_delay_ms(100);
		
		usart_string("S:");
		_delay_ms(100);
		convert(msg3);
		usart_string(con);
		_delay_ms(100);
		usart_transmit(0X0D);
		usart_transmit(0X0A);
		_delay_ms(100);
		
		usart_string("H:");
		_delay_ms(100);
		convert(msg4);
		usart_string(con);
		_delay_ms(100);
		usart_transmit(0X0D);
		usart_transmit(0X0A);
		_delay_ms(100);
		
		usart_string(msg5);
		_delay_ms(100);
		usart_transmit(0X0D);
		usart_transmit(0X0A);		
		_delay_ms(100);
		usart_transmit(0X1A);
		_delay_ms(500);
		usart_transmit(0x1A);
		_delay_ms(500);
		usart_transmit(0x1A);
		_delay_ms(500);
		second_line_clr();
		lcd_command(0xc0);
		lcd_string("    MSG Send    ");     
		_delay_ms(3000);
		lcd_command(0X01);
		
		sei();
		
	}	
	