//-------function declaration-----------------
char receive(void);
void transmit(char t);
void serial_init();
void putstring(const char *z);

//--------function definition-------------
void serial_init()
{
	UCSRA=0X00;
	UCSRB=0X98;
	UCSRC=0X06;
    UBRRL=0x19 ;//baud rate 9600 with 11.0592MHz Xtal
	UBRRH=0X00;
}


char usart_receive(void)
{
	
	while ((UCSRA&(1<<RXC))==0);
	UCSRA&=~(1<<RXC);
	return(UDR);
}

void usart_transmit(char t)
{
	UDR=t;
	while((UCSRA & (1<<TXC))==0);
	UCSRA|=(1<<TXC);	
}

void usart_string(const char *z)
{
	while(*z)
	{
	     _delay_ms(200);
		usart_transmit(*z++);
		 _delay_ms(200); //200
	
	}
}