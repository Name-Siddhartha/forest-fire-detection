void port_init()
{
	
	DDRA=0x00;
	DDRB=0xFF;
	DDRC=0xFF;
 	DDRA|=(1<<1);
	DDRA&=~(1<<4);
	DDRA&=~(1<<5);
	DDRD&=~(1<<2);
	DDRD&=~(1<<0);
	DDRD|=(1<<6);
	DDRD|=(1<<7);
	DDRD|=(1<<4);
	DDRD&=~(1<<5);
	PORTD|=(1<<5);
	PORTB=0x00;
		
}

