/*
 * SERVER.c
 *
 * Created: 16-02-2019 19:03:57
 *  Author: PavaN
 */ 

#include <avr/io.h>

#define F_CPU 4000000UL
#include <util/delay.h>
#include <avr/interrupt.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#include "port_init.h"
#include "lcd_8bit.h"
#include "usart.h"
#include "gsm.h"

#define gsm_tx_en (PORTB|=(1<<2))
#define	gsm_tx_dis (PORTB&=~(1<<2))

#define gsm_rx_en (PORTB|=(1<<3))
#define gsm_rx_dis (PORTB&=~(1<<3))

#define zigb_tx_en (PORTB|=(1<<6))
#define	zigb_tx_dis (PORTB&=~(1<<6))

#define zigb_rx_en (PORTB|=(1<<7))
#define zigb_rx_dis (PORTB&=~(1<<7)) 

#define pc_tx_en (PORTB|=(1<<4))
#define pc_tx_dis (PORTB&=~(1<<4))

#define pc_rx_en (PORTB|=(1<<5))
#define pc_rx_dis (PORTB&=~(1<<5)) 

void check();

char j,flaga=0,flagb=0,urgb=0,urga=0,flg2=0,K;
char msg_data[20],t1[5],w1[5],t2[5],w2[5],a[5],sm1[5],hm1[5],sm2[5],hm2[5],data[20];
int  u,v,y,x,sa,ha,sb,hb;
int main(void)
{
	port_init();
	lcd_init();
		zigb_tx_dis;
		zigb_rx_dis;
		pc_tx_dis;
		pc_rx_dis;
		gsm_rx_en;
		gsm_tx_en;
	 _delay_ms(100);
	lcd_command(0x80);
	 _delay_us(100);
	lcd_string("Wireless Sensor");
	lcd_command(0xc0);
	 _delay_us(100);
 	lcd_string("Network Server");
	 _delay_ms(300);
	
	
	serial_init();
	gsm_initial();
	DDRA=0X00;
	PORTA=0XFf;// INTERNAL PULLUP
	
	 
	 
	 lcd_command(0x01);
	  _delay_ms(50);
	
	sei();
	
    while(1)
    {
	sei();
		zigb_tx_en;
	    zigb_rx_en;
		pc_rx_dis;
		pc_tx_dis;				
		gsm_rx_dis;
		gsm_tx_dis;
		
		lcd_command(0x80);
		 _delay_us(100);
		lcd_string("   Monitoring   ");
		lcd_command(0xc0);
		lcd_string("   Station         ");
		 _delay_ms(1000);
	if (((PIND&(1<<PD5))==0))// RF module (pin internally pulled up(port init))
		{
		lcd_command(0X01);
	    lcd_command(0X80);
		lcd_string("PERSON DETECTED");
		 _delay_ms(1000);
		}
		if (((PINA&(1<<PA5))==0))
		{
				
		cli();
		lcd_command(0x01);
		zigb_tx_en;
		zigb_rx_en;
		pc_rx_dis;
		pc_tx_dis;
		gsm_rx_dis;
		gsm_tx_dis;
		lcd_command(0X80);
		lcd_string("Checking NODE        ");
						
			usart_transmit('A');
			 _delay_us(1000);
			while((usart_receive())!='@');	
			j=0;	
			while((t1[j++]=usart_receive())!='#');
			t1[j-1]='\0';
			  _delay_ms(10);
					
			while((usart_receive())!='$');	
			j=0;	
			while((w1[j++]=usart_receive())!='#');
			w1[j-1]='\0';
			 _delay_ms(10);
					
			while((usart_receive())!='*');	
			j=0;	
			while((sm1[j++]=usart_receive())!='#');
			sm1[j-1]='\0';
			 _delay_ms(10);
					
			while((usart_receive())!='%');	
			j=0;	
			while((hm1[j++]=usart_receive())!='#');
			hm1[j-1]='\0';
				
				
		lcd_command(0X80);		
		lcd_string(" AT:");
		lcd_string(t1);
		lcd_string("  AW:");
		lcd_string(w1);
		lcd_command(0xc0);
		lcd_string(" AS:");
		lcd_string(sm1);
		lcd_string("  AH:");
		lcd_string(hm1);	
		 _delay_ms(3000);
		zigb_tx_dis;
		zigb_rx_dis;
		pc_rx_en;
		pc_tx_en;
		gsm_rx_dis;
		gsm_tx_dis;
		usart_string(" AT:");
		usart_string(t1);
		usart_string("  AW:");
		usart_string(w1);
		usart_string(" AS:");
		usart_string(sm1);
		usart_string("  AH:");
		usart_string(hm1);	
			
				
	sei();
		lcd_command(0x80);
		lcd_string("OK");
		zigb_tx_en;
		zigb_rx_en;
		pc_rx_dis;
	    pc_tx_dis;
		gsm_rx_dis;
		gsm_tx_dis;
		 _delay_ms(5000);
		}	
	}
}						 					
void check()
{
	cli();
				
	if ((u>45) || (v>2) || (sa>60) || (ha>5))
			{
		lcd_command(0x01);
		 _delay_ms(50);
		lcd_command(0xc0);
		 _delay_us(100);
		lcd_command(0X80);
		lcd_string("Critical Condition ");
		lcd_command(0XC0);
		lcd_string("    in A");
		 _delay_ms(1000);
							    
				sendmsg1("919633385167",u,v,sa,ha,"Critical Condition in A");
			}
	
	    zigb_tx_en;
		zigb_rx_en;
		pc_rx_dis;
		pc_tx_dis;
		gsm_rx_dis;
		gsm_tx_dis;	

		UCSRB=0X00;
	sei();
		UCSRB=0X98;		
	}	


ISR (USART_RXC_vect)
{
	
	cli();
		char data;
		data=UDR;
 					
	
		zigb_tx_en;
		zigb_rx_en;
		pc_rx_dis;
		pc_tx_dis;
		gsm_rx_dis;
		gsm_tx_dis;
		if (data=='C')
		{
		lcd_command(0X80);
		lcd_string("Checking NODE    ");	
		 _delay_ms(2000);
		 
			usart_transmit('A');
			 _delay_ms(1);
					
			while((usart_receive())!='@');	
			j=0;	
			while((t1[j++]=usart_receive())!='#');
			t1[j-1]='\0';
			 _delay_ms(10);
		
			while((usart_receive())!='$');	
			j=0;	
			while((w1[j++]=usart_receive())!='#');
			w1[j-1]='\0';
			 _delay_ms(10);
	
			while((usart_receive())!='*');	
			j=0;	
			while((sm1[j++]=usart_receive())!='#');
			sm1[j-1]='\0';
			 _delay_ms(10);
					
			while((usart_receive())!='%');	
			j=0;	
			while((hm1[j++]=usart_receive())!='#');
			hm1[j-1]='\0';
			 _delay_ms(10);
		lcd_command(0X80);
		lcd_string(" AT:");
		lcd_string(t1);
		lcd_string("  AW:");
		lcd_string(w1);
		lcd_command(0xc0);
		lcd_string(" AS:");
		lcd_string(sm1);
		lcd_string("  AH:");
		lcd_string(hm1);	
		 _delay_ms(3000);	
	
		zigb_tx_dis;
		zigb_rx_dis;
		pc_rx_en;
		pc_tx_en;
		gsm_rx_dis;
		gsm_tx_dis;	
		
		u=atoi(t1);
		v=atoi(w1);
		sa=atoi(sm1);
		ha=atoi(hm1);
								
		usart_string(" AT:");
		usart_string(t1);
		usart_string("  AW:");
		usart_string(w1);
		usart_string(" AS:");
		usart_string(sm1);
		usart_string("  AH:");
		usart_string(hm1);
		
	    zigb_tx_en;
		zigb_rx_en;
		pc_rx_dis;
		pc_tx_dis;
		gsm_rx_dis;
		gsm_tx_dis;
 	
		check();

		}
	
	if(data=='?')
		{ 
		lcd_command(0x01);
		 _delay_ms(3);
		lcd_command(0X80);
		lcd_string("Person Alone  ");	
		 _delay_ms(4000);
		 
		zigb_tx_dis;
		zigb_rx_dis;
		pc_tx_dis;
		pc_rx_dis;
		gsm_rx_en;
		gsm_tx_en;
		
		lcd_command(0X01);
		 _delay_ms(50);
		lcd_string("Sending MSG...");
		usart_string("AT+CMGS=");
		 _delay_ms(100);
		usart_transmit('"');
		 _delay_ms(100);
		usart_string("919633385167");
		 _delay_ms(100);
		usart_transmit('"');
		 _delay_ms(100);
		usart_transmit(0X0D);
		usart_transmit(0X0A);
		 _delay_ms(100);
		usart_string("Person Alone In Node A");
		usart_transmit(0X0D);
		usart_transmit(0X0A);
		usart_transmit(0x1A);
		 _delay_ms(100);
	    usart_transmit(0x1A);
		
		zigb_tx_en;
		zigb_rx_en;
		pc_rx_dis;
		pc_tx_dis;
		gsm_rx_dis;
		gsm_tx_dis;
		}
	sei();
}


