/*
 * NODE_1.c
 *
 * Created: 16-02-2019 18:44:49
 *  Author: PavaN
 */ 

#include <avr/io.h>

#define F_CPU 4000000UL
#include <util/delay.h>
#include <avr/interrupt.h>

#include "port_init.h"
#include "lcd_8bit.h"
#include "adc.h"
#include "usart.h"

char t,w,s,h,flag1=0;
char m='E';

int main(void)
{
	
	port_init();
	lcd_init();
	adc_initial();
	serial_init();
	GICR|=(1<<INT0);
	MCUCR=0X00;
	
	lcd_command(0x80);
	 _delay_us(100);
	lcd_string("Wireless Sensor");
	lcd_command(0xc0);
	 _delay_us(100);
 	lcd_string("    Network    ");
	 _delay_ms(300);
	 
	 
	lcd_command(0x01);
	 _delay_ms(50);
	 
	sei();

    while(1)
	{
		temperature();
	}

}



void temperature()
{

	lcd_command(0x80);
	lcd_string("T:");
	t=adc_value(0);
	t=((t*500)/256);
	hex_ascii(t);
    lcd_command(0x82);
	lcd_string(con);
	 _delay_ms(100);
	lcd_command(0x86);
	lcd_string("W:");
	w=adc_value(1);
	hex_ascii(w);
    lcd_command(0x89);
	lcd_string(con);
	 _delay_ms(100);
	lcd_command(0xc0);
	lcd_string("S:");
	s=adc_value(3);
	hex_ascii(s);
    lcd_command(0xc2);
	lcd_string(con);
	 _delay_ms(100);
	lcd_command(0xc5);
	lcd_string(" H:");
	lcd_command(0xcB);
	lcd_string("   ");
	h=adc_value(2);
	h=((h)+6);
	hex_ascii(h);
    lcd_command(0xc8);
	lcd_string(con);
	 _delay_ms(100);
	 
	 
	if (t>45)
	{
		
		PORTB|=(1<<0);
		PORTB|=(1<<1);
		 _delay_ms(100);
		lcd_command(0xc0);
		lcd_string("                ");
		lcd_command(0xc0);
	     _delay_us(100);
		lcd_string("Temp Very High ");
		 _delay_ms(300);
				
		
			usart_transmit('C');
			 _delay_ms(10);
	}
	if (w>2)
	{
		lcd_command(0xc0);
		 _delay_us(100);
		lcd_string("Wind Very High    ");
		 _delay_ms(300);
		
		
			usart_transmit('C');
			 _delay_ms(10);
		
	}
	if (h>5)
	{
		lcd_command(0xc0);
		 _delay_us(100);
		lcd_string("Humidity Very High    ");
		 _delay_ms(300);
		
		
			usart_transmit('C');
			 _delay_ms(10);
		
	}
	if (s>60)
	{
		lcd_command(0x01);
	     _delay_ms(50);
		lcd_command(0xc0);
		 _delay_us(100);
		lcd_string("Smoke Detected    ");
		 _delay_ms(500);
		
			usart_transmit('C');
			 _delay_ms(10);
		
	}
	}


ISR(USART_RXC_vect)
{
	
	cli();
	UCSRB=0x18;
	char a;
	a=UDR;
		
	
	if (a=='A')
	{
		UCSRB|=(1<<TXEN);
	
		lcd_command(0x01);
		 _delay_ms(50);
		lcd_string("Send val 2 servr");
		
			usart_transmit('@');
			hex_ascii(t);
			usart_string(con);
		
			usart_transmit('#');
			 _delay_ms(100);
		
			usart_transmit('$');
			hex_ascii(w);
			usart_string(con);
		
			usart_transmit('#');
			 _delay_ms(100);
		

			usart_transmit('*');
			hex_ascii(s);
			usart_string(con);
		
			usart_transmit('#');
			 _delay_ms(100);
		
			usart_transmit('%');
			hex_ascii(h);
			usart_string(con);
		
			usart_transmit('#');
			 _delay_ms(100);
		
		
			lcd_command(0x01);
			 _delay_ms(50);
		
		UCSRB&=~(1<<TXEN);
	}
	
	UCSRB=0x98;
	sei();
}	
ISR(INT0_vect)
{
	cli();
	lcd_command(0x01);
	 _delay_ms(10);
	lcd_string("Alone");
	 _delay_ms(100);
	
		usart_transmit('?');
	
	sei();
}	