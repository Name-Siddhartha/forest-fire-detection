#define F_CPU 4000000UL
#include <util/delay.h>

void adc_initial(void);
void hex_ascii(char u);
void adc_disp(int c,int l);
int adc_value(int c);

int d;
char con[5];
void adc_initial(void)
{
	ADCSRA=0x87;
}

void hex_ascii (char u)
{ 
    con[3]='\0';
	con[2]=(u%10)+0x30;
	u=u/10;
    con[1]=(u%10)+0x30;
    con[0]=(u/10)+0x30;
}

int adc_value(int c)
{
	int ch;
	ch=0x60+c;
	ADMUX=ch;
	ADCSRA|=(1<<ADSC);
	while((ADCSRA&(1<<ADIF))==0);
	d=ADCH;
	return(d);
}

void adc_disp(int c,int l)
{
	int ch;
	ch=0x60+c;
	ADMUX=ch;
	ADCSRA|=(1<<ADSC);
	while((ADCSRA&(1<<ADIF))==0);
	d=ADCH;
	hex_ascii(d);
    lcd_command(l);
	lcd_string(con);
	
}	