#define LCD_PORT PORTC
#define LCD_CTRL PORTD
#define LCD_RS 6 //of PORTD
#define LCD_EN 7 //of PORTD
#define LCD_BUSY 7 //of PORTC

void lcd_init();
void lcd_command(char c);
void lcd_data(char d);
void lcd_string(const char*s);
void convert(char u);
void busy_flag();
void delay (char x);
void second_line_clr();
char con[5];

void second_line_clr()
{
	lcd_command(0xc0);
	lcd_string("                ");
}

void lcd_init()
{
	 _delay_ms(15);
	lcd_command(0X38);
	 _delay_us(100);
	lcd_command(0X80);
	 _delay_us(100);
	lcd_command(0X0C);
	 _delay_us(100);
	lcd_command(0X06);
	 _delay_us(100);
	lcd_command(0X01);
	 _delay_ms(2); 	
}

void lcd_command(char c)
{
	//busy_flag();
	LCD_PORT= c;
	 _delay_us(100);
	LCD_CTRL&=~(1<<LCD_RS);
	
	LCD_CTRL|=(1<<LCD_EN);
	 _delay_us(15);
	LCD_CTRL&=~(1<<LCD_EN);
}

void delay (char x)
{
	int i,j;
	for(j=0;j<x;j++)
	for(i=0;i<1000;i++);
}


void lcd_data(char d)
{
	//busy_flag();
	LCD_PORT= d;
	 _delay_us(100);
	LCD_CTRL|=(1<<LCD_RS);
	
	LCD_CTRL|=(1<<LCD_EN);
	 _delay_us(15);
	LCD_CTRL&=~(1<<LCD_EN);
}

void lcd_string(const char*s)
{
	while(*s)
	{
		lcd_data(*s++);
		 _delay_us(100);
	}
}
void busy_flag()
{
	DDRC&=~(1<<7);
	LCD_CTRL&=~(1<<LCD_RS);
	while((PINC&(1<<7))==1)
	{
	LCD_CTRL|=(1<<LCD_EN);
	_delay_us(1);
	LCD_CTRL&=~(1<<LCD_EN);
	}
	DDRC|=(1<<7);
}
void convert(char u)
{
	con[3]='\0';
	con[2]=(u%10)+0x30;
	u=u/10;
    con[1]=(u%10)+0x30;
    con[0]=(u/10)+0x30;
}
